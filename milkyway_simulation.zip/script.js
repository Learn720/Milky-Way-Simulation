
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  2000
);
camera.position.z = 30;

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const controls = new THREE.OrbitControls(camera, renderer.domElement);

const loader = new THREE.TextureLoader();
loader.load("assets/stars.jpg", function (texture) {
  scene.background = texture;
});

const starCount = 5000;
const geometry = new THREE.BufferGeometry();
const positions = [];

for (let i = 0; i < starCount; i++) {
  const radius = Math.random() * 50;
  const angle = radius * 2 + Math.random() * 2;
  const x = Math.cos(angle) * radius;
  const y = (Math.random() - 0.5) * 5;
  const z = Math.sin(angle) * radius;
  positions.push(x, y, z);
}

geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));

const starMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.1 });
const stars = new THREE.Points(geometry, starMaterial);
scene.add(stars);

const diskTexture = loader.load("assets/galaxy.jpg");
const diskMaterial = new THREE.MeshBasicMaterial({ map: diskTexture, side: THREE.DoubleSide });
const disk = new THREE.Mesh(new THREE.CircleGeometry(25, 64), diskMaterial);
disk.rotation.x = Math.PI / 2;
scene.add(disk);

const celestialBodies = [
  { name: "Alpha Centauri", pos: [10, 0, 5], type: "Star System", dist: "4.37 ly" },
  { name: "Betelgeuse", pos: [-15, 3, 2], type: "Red Supergiant", dist: "642 ly" },
  { name: "Andromeda", pos: [60, 20, 0], type: "Galaxy", dist: "2.5 million ly" },
  { name: "Sagittarius A*", pos: [0, 0, 0], type: "Supermassive Black Hole", dist: "26k ly" }
];

const infoBox = document.getElementById("infoBox");
const speech = window.speechSynthesis;
let objects = [];

celestialBodies.forEach(body => {
  const star = new THREE.Mesh(
    new THREE.SphereGeometry(0.5, 16, 16),
    new THREE.MeshBasicMaterial({ color: 0xffdd00 })
  );
  star.position.set(...body.pos);
  star.userData = body;
  scene.add(star);
  objects.push(star);
});

const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

window.addEventListener("click", event => {
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObjects(objects);
  if (intersects.length > 0) {
    const obj = intersects[0].object.userData;
    const text = `${obj.name}, a ${obj.type}, approximately ${obj.dist} from Earth.`;
    infoBox.innerHTML = `<strong>${obj.name}</strong><br>Type: ${obj.type}<br>Distance: ${obj.dist}`;
    infoBox.style.display = "block";

    if (speech) {
      speech.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      speech.speak(utter);
    }
  } else {
    infoBox.style.display = "none";
  }
});

window.zoomTo = function (target) {
  const targets = {
    center: new THREE.Vector3(0, 0, 30),
    solar: new THREE.Vector3(10, 0, 5),
    andromeda: new THREE.Vector3(60, 20, 30)
  };
  controls.target = targets[target];
  camera.position.copy(targets[target]);
  controls.update();
};

function animate() {
  requestAnimationFrame(animate);
  stars.rotation.y += 0.0008;
  disk.rotation.z += 0.0003;
  renderer.render(scene, camera);
}
animate();

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
